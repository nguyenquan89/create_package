<?php 

function testTest()
{
	return 'tesst';
}