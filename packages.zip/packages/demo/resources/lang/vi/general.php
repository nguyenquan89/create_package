<?php 

return [
	'demo' => 'Đây là demo array',
];