<h1>@lang('Demo::general.demo')</h1>
<h1>@lang('Đây là demo')</h1>